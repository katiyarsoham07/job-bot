# Soham's Daily Job Bot 🎯

Fetches 50+ Sales/BD/GM jobs daily from LinkedIn, Indeed, Instahyre, Cutshort + more.
Scores each job using Claude AI against your profile.
Displays results in a live web dashboard.

## Setup (15 minutes, completely free)

### Step 1 — Create GitHub Repository
1. Go to github.com → New Repository
2. Name it: `job-bot` (must be public for GitHub Pages)
3. Upload all these files into it

### Step 2 — Add Your API Key (Secret)
1. In your repo → Settings → Secrets and variables → Actions
2. Click "New repository secret"
3. Name: `ANTHROPIC_API_KEY`
4. Value: Your key from console.anthropic.com (free tier works)

### Step 3 — Enable GitHub Pages (your dashboard URL)
1. In your repo → Settings → Pages
2. Source: Deploy from a branch
3. Branch: main → / (root)
4. Save
5. Your dashboard will be live at: `https://YOUR-USERNAME.github.io/job-bot/`

### Step 4 — Run It Now (don't wait for tomorrow)
1. In your repo → Actions tab
2. Click "Daily Job Fetch"
3. Click "Run workflow" → Run workflow
4. Wait ~2 minutes
5. Visit your dashboard URL — 50 jobs ready!

### Step 5 — It Runs Automatically Every Day
The GitHub Action runs at 7:30 AM IST daily.
You just open the dashboard and see fresh jobs.

---

## What You See on the Dashboard

- 🔥 **High Match (8+)** — Top jobs Claude thinks are perfect for you
- ✅ **Good Match (6–7.9)** — Strong options worth reviewing
- ⭐ **Save** — Bookmark jobs to apply later
- 🔍 **Search** — Filter by company, role, location
- **Apply Now** — Directly opens the job listing

## Sources
- LinkedIn (public RSS — no account ban risk)
- Indeed India (official RSS API)
- Instahyre
- Cutshort
- Shine
- FreshersWorld

## Cost
- GitHub Actions: **FREE** (2000 min/month free)
- Claude API: **~₹2-5/day** (scoring 50-80 jobs)
- Hosting: **FREE** (GitHub Pages)

**Total: ~₹100-150/month**
