"""
Job Fetcher + AI Scorer for Soham Katiyar
Fetches 50+ jobs daily from LinkedIn RSS, Indeed, Naukri, Instahyre, Cutshort, etc.
Scores each job against Soham's profile using Claude API.
Saves results to jobs.json (served via GitHub Pages dashboard).
"""

import json
import os
import re
import time
import hashlib
from datetime import datetime, timezone
from urllib.request import urlopen, Request
from urllib.error import URLError
import xml.etree.ElementTree as ET

# ─── CONFIG ────────────────────────────────────────────────────────────────

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")

CANDIDATE_PROFILE = """
Name: Soham Katiyar
Education: MBA (IIM Kozhikode, 2023-2025), B.Sc. Agriculture Gold Medalist
Current/Last Role: General Manager - Sales & Business Development, RAAM Group (JSW MG Motors)
Experience: 2+ years in Sales, Business Development, Strategy, General Management
Key Skills: Corporate Sales, B2B/B2C Sales, GTM Strategy, Key Account Management,
            Channel Management, P&L Ownership, Team Leadership (32 members),
            Market Penetration, Revenue Growth 20%+, CRM, Sales Forecasting
Location: Kanpur, India (Open to Pan-India and remote)
Target Roles: Sales Manager, Business Development Manager, General Manager,
              Strategy Manager, Key Account Manager, GTM Manager, Regional Sales Manager
Target Industries: FMCG, Automotive, AgriTech, Financial Services, E-commerce, SaaS, Startups
Target Companies: Any company with strong sales culture, startups to mid-large corporates
Salary Expectation: Open (MBA from IIM K premium expected)
"""

# Job search queries for different platforms
SEARCH_QUERIES = [
    "Sales+Manager",
    "Business+Development+Manager",
    "General+Manager+Sales",
    "Key+Account+Manager",
    "Regional+Sales+Manager",
    "GTM+Manager",
    "Sales+Strategy+Manager",
    "Corporate+Sales+Manager",
]

INDIA_LOCATIONS = [
    "India",
    "Mumbai%2C+India",
    "Delhi%2C+India",
    "Bangalore%2C+India",
    "Hyderabad%2C+India",
    "Pune%2C+India",
    "Kanpur%2C+India",
]

OUTPUT_FILE = "jobs.json"
MAX_JOBS_PER_SOURCE = 15
MAX_TOTAL_JOBS = 80  # fetch more, score top 50

# ─── RSS FETCHERS ──────────────────────────────────────────────────────────

def fetch_rss(url, source_name, timeout=15):
    """Fetch and parse an RSS feed."""
    jobs = []
    try:
        req = Request(url, headers={"User-Agent": "Mozilla/5.0 JobBot/1.0"})
        with urlopen(req, timeout=timeout) as resp:
            content = resp.read()
        root = ET.fromstring(content)
        channel = root.find("channel")
        if channel is None:
            channel = root
        items = channel.findall("item")
        for item in items[:MAX_JOBS_PER_SOURCE]:
            title = (item.findtext("title") or "").strip()
            link  = (item.findtext("link")  or "").strip()
            desc  = (item.findtext("description") or "").strip()
            pub   = (item.findtext("pubDate") or datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")).strip()
            # Clean HTML from description
            desc = re.sub(r"<[^>]+>", " ", desc)
            desc = re.sub(r"\s+", " ", desc).strip()[:300]
            if title and link:
                jobs.append({
                    "id": hashlib.md5(link.encode()).hexdigest()[:10],
                    "title": title,
                    "link": link,
                    "description": desc,
                    "published": pub,
                    "source": source_name,
                    "score": 0,
                    "reason": "",
                    "company": extract_company(title, desc),
                    "location": extract_location(title, desc),
                })
    except Exception as e:
        print(f"  [WARN] {source_name}: {e}")
    return jobs


def extract_company(title, desc):
    """Try to extract company name from title/description."""
    # Pattern: "Role at Company" or "Role - Company"
    m = re.search(r"(?:at|@|-|–)\s+([A-Z][A-Za-z0-9\s&.,]+?)(?:\s*[-|,]|$)", title)
    if m:
        return m.group(1).strip()[:60]
    m = re.search(r"Company[:\s]+([A-Z][A-Za-z0-9\s&.,]+?)(?:\s*[\n|,]|$)", desc)
    if m:
        return m.group(1).strip()[:60]
    return "N/A"


def extract_location(title, desc):
    """Try to extract location."""
    cities = ["Mumbai","Delhi","Bangalore","Hyderabad","Pune","Chennai","Kolkata",
              "Kanpur","Lucknow","Noida","Gurgaon","Gurugram","Ahmedabad","Jaipur",
              "Remote","Pan-India","India"]
    for c in cities:
        if c.lower() in title.lower() or c.lower() in desc.lower():
            return c
    return "India"


def fetch_linkedin_rss(query, location="India"):
    url = (f"https://www.linkedin.com/jobs/search/?keywords={query}"
           f"&location={location}&f_TPR=r86400&position=1&pageNum=0"
           f"&format=rss")
    return fetch_rss(url, "LinkedIn")


def fetch_indeed_rss(query, location="India"):
    url = (f"https://in.indeed.com/rss?q={query}&l={location}"
           f"&fromage=1&sort=date")
    return fetch_rss(url, "Indeed")


def fetch_instahyre_rss():
    urls = [
        "https://www.instahyre.com/jobs/sales-manager/rss/",
        "https://www.instahyre.com/jobs/business-development/rss/",
    ]
    jobs = []
    for url in urls:
        jobs += fetch_rss(url, "Instahyre")
    return jobs


def fetch_cutshort_rss():
    url = "https://cutshort.io/jobs/sales/rss"
    return fetch_rss(url, "Cutshort")


def fetch_naukri_via_indeed():
    """
    Naukri doesn't allow scraping, but Indeed India indexes most Naukri jobs.
    We search Indeed with Naukri-specific terms.
    """
    jobs = []
    extra_queries = ["Sales+Head", "VP+Sales", "Business+Development+Head"]
    for q in extra_queries:
        jobs += fetch_indeed_rss(q, "India")
    return jobs


def fetch_freshersworld_rss():
    url = "https://www.freshersworld.com/jobs/jobsearch/Sales-Manager-jobs-for-freshers-and-experienced?industry=Sales-Marketing&subscribe=rss"
    return fetch_rss(url, "FreshersWorld")


def fetch_shine_rss():
    url = "https://www.shine.com/sitemap/jobs-rss.xml"
    return fetch_rss(url, "Shine")


# ─── MAIN FETCH ────────────────────────────────────────────────────────────

def fetch_all_jobs():
    all_jobs = []
    seen_ids = set()

    print("Fetching LinkedIn RSS...")
    for query in SEARCH_QUERIES[:4]:
        jobs = fetch_linkedin_rss(query, "India")
        print(f"  LinkedIn [{query}]: {len(jobs)} jobs")
        all_jobs += jobs
        time.sleep(1)

    print("Fetching Indeed RSS...")
    for query in SEARCH_QUERIES:
        jobs = fetch_indeed_rss(query, "India")
        print(f"  Indeed [{query}]: {len(jobs)} jobs")
        all_jobs += jobs
        time.sleep(0.5)

    print("Fetching Instahyre RSS...")
    jobs = fetch_instahyre_rss()
    print(f"  Instahyre: {len(jobs)} jobs")
    all_jobs += jobs

    print("Fetching Cutshort RSS...")
    jobs = fetch_cutshort_rss()
    print(f"  Cutshort: {len(jobs)} jobs")
    all_jobs += jobs

    print("Fetching extra Indeed (Naukri-indexed)...")
    jobs = fetch_naukri_via_indeed()
    print(f"  Indeed Extra: {len(jobs)} jobs")
    all_jobs += jobs

    # Deduplicate
    unique = []
    for job in all_jobs:
        if job["id"] not in seen_ids:
            seen_ids.add(job["id"])
            unique.append(job)

    print(f"\nTotal unique jobs fetched: {len(unique)}")
    return unique[:MAX_TOTAL_JOBS]


# ─── AI SCORING ────────────────────────────────────────────────────────────

def score_jobs_with_claude(jobs):
    """Score jobs in batches using Claude API."""
    if not ANTHROPIC_API_KEY:
        print("[WARN] No API key — using keyword scoring fallback.")
        return keyword_score_jobs(jobs)

    import urllib.request, json as _json

    scored = []
    batch_size = 10
    batches = [jobs[i:i+batch_size] for i in range(0, len(jobs), batch_size)]

    for i, batch in enumerate(batches):
        print(f"  Scoring batch {i+1}/{len(batches)}...")
        jobs_text = "\n".join([
            f"JOB_{j+1}: {job['title']} | {job['company']} | {job['location']}\n"
            f"DESC: {job['description'][:200]}"
            for j, job in enumerate(batch)
        ])

        prompt = f"""You are an HR expert. Score each job for the following candidate:

CANDIDATE PROFILE:
{CANDIDATE_PROFILE}

JOBS TO SCORE:
{jobs_text}

For each job JOB_1 through JOB_{len(batch)}, respond ONLY with JSON like this:
[
  {{"job": "JOB_1", "score": 8.5, "reason": "Strong B2B sales role, matches IIM MBA profile, automotive sector fit"}},
  ...
]

Score from 1-10. Only JSON, no other text."""

        try:
            payload = _json.dumps({
                "model": "claude-sonnet-4-20250514",
                "max_tokens": 1000,
                "messages": [{"role": "user", "content": prompt}]
            }).encode()

            req = urllib.request.Request(
                "https://api.anthropic.com/v1/messages",
                data=payload,
                headers={
                    "Content-Type": "application/json",
                    "x-api-key": ANTHROPIC_API_KEY,
                    "anthropic-version": "2023-06-01"
                },
                method="POST"
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                result = _json.loads(resp.read())
                text = result["content"][0]["text"]
                # Extract JSON
                match = re.search(r'\[.*\]', text, re.DOTALL)
                if match:
                    scores = _json.loads(match.group())
                    for s in scores:
                        idx = int(re.search(r'\d+', s["job"]).group()) - 1
                        if 0 <= idx < len(batch):
                            batch[idx]["score"] = s.get("score", 5)
                            batch[idx]["reason"] = s.get("reason", "")
        except Exception as e:
            print(f"  [WARN] Claude scoring failed: {e}")
            for job in batch:
                job["score"] = keyword_score(job)
                job["reason"] = "Keyword match scoring"

        scored += batch
        time.sleep(1)

    return scored


def keyword_score(job):
    """Fallback keyword-based scoring."""
    text = (job["title"] + " " + job["description"]).lower()
    score = 3.0
    high_match = ["sales manager","business development","key account","general manager",
                  "gtm","corporate sales","regional sales","vp sales","head of sales"]
    med_match  = ["sales","business development","account","revenue","b2b","b2c","fmcg","startup"]
    for kw in high_match:
        if kw in text: score += 0.8
    for kw in med_match:
        if kw in text: score += 0.3
    return min(round(score, 1), 10.0)


def keyword_score_jobs(jobs):
    for job in jobs:
        job["score"] = keyword_score(job)
        job["reason"] = "Keyword match scoring (no API key)"
    return jobs


# ─── SAVE OUTPUT ───────────────────────────────────────────────────────────

def save_output(jobs):
    # Sort by score descending
    jobs.sort(key=lambda j: j["score"], reverse=True)
    top_jobs = jobs[:50]

    output = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "total_fetched": len(jobs),
        "total_shown": len(top_jobs),
        "jobs": top_jobs
    }

    with open(OUTPUT_FILE, "w") as f:
        json.dump(output, f, indent=2)

    print(f"\n✅ Saved {len(top_jobs)} jobs to {OUTPUT_FILE}")
    print(f"Top 5 jobs:")
    for j in top_jobs[:5]:
        print(f"  [{j['score']}] {j['title']} @ {j['company']} ({j['source']})")


# ─── ENTRY POINT ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    print(f"=== Job Bot Starting at {datetime.now().strftime('%Y-%m-%d %H:%M')} ===\n")
    jobs = fetch_all_jobs()
    print(f"\nScoring jobs with AI...")
    jobs = score_jobs_with_claude(jobs)
    save_output(jobs)
    print("\n=== Done ===")
